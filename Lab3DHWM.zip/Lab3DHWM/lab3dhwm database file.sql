-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 22, 2019 at 07:54 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `lab3dhwm`
--

-- --------------------------------------------------------

--
-- Table structure for table `delayreason`
--

CREATE TABLE IF NOT EXISTS `delayreason` (
  `Reasoncode` varchar(10) NOT NULL,
  `Name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `delayreason`
--

INSERT INTO `delayreason` (`Reasoncode`, `Name`) VALUES
('S', 'No SSpare'),
('V', 'Vendor');

-- --------------------------------------------------------

--
-- Table structure for table `downreason`
--

CREATE TABLE IF NOT EXISTS `downreason` (
  `Reasoncode` varchar(10) NOT NULL,
  `Name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `downreason`
--

INSERT INTO `downreason` (`Reasoncode`, `Name`) VALUES
('B', 'Broken Part'),
('B', 'Over Heated');

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE IF NOT EXISTS `event` (
  `EventID` int(30) NOT NULL,
  `Duration` int(30) NOT NULL,
  `StatusCode` varchar(10) NOT NULL,
  `Reasoncode` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`EventID`, `Duration`, `StatusCode`, `Reasoncode`) VALUES
(1, 5, 'R', 'S'),
(2, 60, 'D1', 'S'),
(3, 10, 'S', 'C'),
(4, 20, 'D2', 'S'),
(5, 15, 'S', 'H'),
(6, 25, 'D1', 'V'),
(7, 20, 'R', 'S'),
(8, 60, 'D2', 'B');

-- --------------------------------------------------------

--
-- Table structure for table `readyreason`
--

CREATE TABLE IF NOT EXISTS `readyreason` (
  `Reasoncode` varchar(10) NOT NULL,
  `Name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `readyreason`
--

INSERT INTO `readyreason` (`Reasoncode`, `Name`) VALUES
('S', 'StandBy'),
('R', 'Running');

-- --------------------------------------------------------

--
-- Table structure for table `sparereason`
--

CREATE TABLE IF NOT EXISTS `sparereason` (
  `Reasoncode` varchar(10) NOT NULL,
  `Name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sparereason`
--

INSERT INTO `sparereason` (`Reasoncode`, `Name`) VALUES
('C', 'Cold Spare'),
('H', 'Hot Spare');

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE IF NOT EXISTS `status` (
  `StatusCode` varchar(10) NOT NULL,
  `Name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`StatusCode`, `Name`) VALUES
('R', 'Ready'),
('D1', 'Delay'),
('S', 'Spare'),
('D2', 'Down');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
