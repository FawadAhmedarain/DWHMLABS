-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 18, 2019 at 03:33 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `lab2`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity`
--

CREATE TABLE IF NOT EXISTS `activity` (
`activity_id` int(11) NOT NULL,
  `activity_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `activity`
--

INSERT INTO `activity` (`activity_id`, `activity_name`) VALUES
(1, 'Game'),
(2, 'Programming'),
(3, 'Teaching'),
(4, 'Shopekeaper');

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE IF NOT EXISTS `book` (
  `isbn_number` varchar(30) NOT NULL,
  `title` varchar(30) DEFAULT NULL,
  `price` double(16,4) DEFAULT NULL,
  `date_of_publication` date DEFAULT NULL,
  `publisher_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`isbn_number`, `title`, `price`, `date_of_publication`, `publisher_id`) VALUES
('', 'MassAnd Communication', 1200.0000, '2019-06-05', 1),
('12345923123-ISO', 'The Hero', 1300.0000, '2019-06-12', 3),
('2191968680-ISO', 'The Life', 1500.0000, '2019-06-05', 1),
('34561234567-ISO', 'Applied solution', 500.0000, '2018-02-03', 1),
('45434343456-ISO', 'Graphic Designer', 2200.0000, '2019-02-01', 2),
('956868680-ISO', 'Freakonomics', 8900.0000, '2018-12-10', 5);

-- --------------------------------------------------------

--
-- Table structure for table `college_course`
--

CREATE TABLE IF NOT EXISTS `college_course` (
`course_id` int(11) NOT NULL,
  `course_name` varchar(255) DEFAULT NULL,
  `units` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `college_course`
--

INSERT INTO `college_course` (`course_id`, `course_name`, `units`) VALUES
(1, 'Calculus', '1'),
(2, 'SQTA', '2'),
(3, 'WT', '6'),
(4, 'CP', '4'),
(5, 'AI', '1');

-- --------------------------------------------------------

--
-- Table structure for table `designer`
--

CREATE TABLE IF NOT EXISTS `designer` (
`desginer_id` int(11) NOT NULL,
  `designer_name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `designer`
--

INSERT INTO `designer` (`desginer_id`, `designer_name`) VALUES
(1, 'Aslam'),
(2, 'Akram'),
(3, 'Arsalan'),
(4, 'Bilal'),
(5, 'Faheem');

-- --------------------------------------------------------

--
-- Table structure for table `hospitaldata`
--

CREATE TABLE IF NOT EXISTS `hospitaldata` (
  `Facility` varchar(30) NOT NULL,
  `Physician` varchar(30) NOT NULL,
  `Ward` varchar(30) NOT NULL,
  `Patient` varchar(30) NOT NULL,
  `Diagnostic unit` varchar(30) NOT NULL,
  `Order` varchar(30) NOT NULL,
  `Supply item` varchar(30) NOT NULL,
  `Vendor` varchar(30) NOT NULL,
  `Service Drug` varchar(30) NOT NULL,
  `Medical item` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hospitaldata`
--

INSERT INTO `hospitaldata` (`Facility`, `Physician`, `Ward`, `Patient`, `Diagnostic unit`, `Order`, `Supply item`, `Vendor`, `Service Drug`, `Medical item`) VALUES
('Lift in Hospital', 'Dr Ayaz', 'Obstetrics', 'Ibrar', 'radiology', '2', 'Box aweeper', 'House keeping', 'lipid profile', 'MRIs '),
('Provide Room for patient', 'Dr Imran', 'Oncology', 'Ali', 'Clinical Laboratory', '2', 'Basket', 'Maintainence Purpose', 'CBC', 'X-rays'),
('Lift in Hospital', 'Dr Ayaz', 'Obstetrics', 'Ibrar', 'radiology', '2', 'Box aweeper', 'House keeping', 'lipid profile', 'MRIs '),
('Provide Room for patient', 'Dr Imran', 'Oncology', 'Ali', 'Clinical Laboratory', '2', 'Basket', 'Maintainence Purpose', 'CBC', 'X-rays');

-- --------------------------------------------------------

--
-- Table structure for table `model`
--

CREATE TABLE IF NOT EXISTS `model` (
`id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `serial_num` int(11) DEFAULT NULL,
  `designer_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `model`
--

INSERT INTO `model` (`id`, `name`, `serial_num`, `designer_id`) VALUES
(1, 'Ai123', 1, 2),
(2, 'Ap562', 2, 1),
(3, 'rt67', 3, 1),
(4, 'de456', 3, 2),
(8, 'rt679', 4, 4);

-- --------------------------------------------------------

--
-- Table structure for table `piano`
--

CREATE TABLE IF NOT EXISTS `piano` (
`serial_num` int(11) NOT NULL,
  `mfg_completion_date` date DEFAULT NULL,
  `emp_num` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `piano`
--

INSERT INTO `piano` (`serial_num`, `mfg_completion_date`, `emp_num`) VALUES
(1, '2019-04-03', 1),
(2, '2019-02-08', 2),
(3, '2010-04-01', 2),
(4, '1957-06-07', 4),
(5, '2013-01-08', 5);

-- --------------------------------------------------------

--
-- Table structure for table `publisher`
--

CREATE TABLE IF NOT EXISTS `publisher` (
`publisher_id` int(11) NOT NULL,
  `name` varchar(40) DEFAULT NULL,
  `number` varchar(20) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `publisher`
--

INSERT INTO `publisher` (`publisher_id`, `name`, `number`) VALUES
(1, 'Fawad Ahmed', '03353631923'),
(2, 'Jawad Ahmed', '03363372895'),
(3, 'Ayaz Ahmed', '03333425582'),
(4, 'Sajeel', '0347056789'),
(5, 'Hshir', '03334512389');

-- --------------------------------------------------------

--
-- Table structure for table `schedule_section`
--

CREATE TABLE IF NOT EXISTS `schedule_section` (
`semister_id` int(11) NOT NULL,
  `section_num` int(11) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schedule_section`
--

INSERT INTO `schedule_section` (`semister_id`, `section_num`, `course_id`) VALUES
(1, 1, 1),
(2, 1, 1),
(3, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `student_phone` varchar(20) NOT NULL,
  `student_name` varchar(50) DEFAULT NULL,
  `address` varchar(20) DEFAULT NULL,
  `age` int(5) DEFAULT NULL,
  `no_of_years` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_phone`, `student_name`, `address`, `age`, `no_of_years`) VALUES
('', 'Fawad', 'Kunri', 22, 4),
('0333256487', 'Saad', 'Hyd', 22, 4),
('034123123123', 'Bilal', 'Mirpurkhas', 19, 4),
('03456789234', 'Akram', 'Karachi', 19, 4),
('03467891233', 'Sanjay', 'Hyderabad', 22, 4);

-- --------------------------------------------------------

--
-- Table structure for table `student_activity`
--

CREATE TABLE IF NOT EXISTS `student_activity` (
  `student_phone` varchar(20) DEFAULT NULL,
  `activity_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_activity`
--

INSERT INTO `student_activity` (`student_phone`, `activity_id`) VALUES
('03467891233', 2),
('034123123123', 1);

-- --------------------------------------------------------

--
-- Table structure for table `techinican`
--

CREATE TABLE IF NOT EXISTS `techinican` (
`emp_num` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `superiver_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `techinican`
--

INSERT INTO `techinican` (`emp_num`, `name`, `superiver_id`) VALUES
(1, 'Hasan', 1),
(2, 'Raza', 5),
(3, 'Nasir', 1),
(4, 'Zohaib', 5),
(5, 'Amir', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity`
--
ALTER TABLE `activity`
 ADD PRIMARY KEY (`activity_id`);

--
-- Indexes for table `book`
--
ALTER TABLE `book`
 ADD PRIMARY KEY (`isbn_number`), ADD KEY `publisher_id` (`publisher_id`);

--
-- Indexes for table `college_course`
--
ALTER TABLE `college_course`
 ADD PRIMARY KEY (`course_id`);

--
-- Indexes for table `designer`
--
ALTER TABLE `designer`
 ADD PRIMARY KEY (`desginer_id`);

--
-- Indexes for table `model`
--
ALTER TABLE `model`
 ADD PRIMARY KEY (`id`), ADD KEY `serial_num` (`serial_num`), ADD KEY `designer_id` (`designer_id`);

--
-- Indexes for table `piano`
--
ALTER TABLE `piano`
 ADD PRIMARY KEY (`serial_num`), ADD KEY `emp_num` (`emp_num`);

--
-- Indexes for table `publisher`
--
ALTER TABLE `publisher`
 ADD PRIMARY KEY (`publisher_id`);

--
-- Indexes for table `schedule_section`
--
ALTER TABLE `schedule_section`
 ADD PRIMARY KEY (`semister_id`), ADD KEY `course_id` (`course_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
 ADD PRIMARY KEY (`student_phone`);

--
-- Indexes for table `student_activity`
--
ALTER TABLE `student_activity`
 ADD KEY `activity_id` (`activity_id`), ADD KEY `student_phone` (`student_phone`);

--
-- Indexes for table `techinican`
--
ALTER TABLE `techinican`
 ADD PRIMARY KEY (`emp_num`), ADD KEY `superiver_id` (`superiver_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity`
--
ALTER TABLE `activity`
MODIFY `activity_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `college_course`
--
ALTER TABLE `college_course`
MODIFY `course_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `designer`
--
ALTER TABLE `designer`
MODIFY `desginer_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `model`
--
ALTER TABLE `model`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `piano`
--
ALTER TABLE `piano`
MODIFY `serial_num` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `publisher`
--
ALTER TABLE `publisher`
MODIFY `publisher_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `schedule_section`
--
ALTER TABLE `schedule_section`
MODIFY `semister_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `techinican`
--
ALTER TABLE `techinican`
MODIFY `emp_num` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `book`
--
ALTER TABLE `book`
ADD CONSTRAINT `book_ibfk_1` FOREIGN KEY (`publisher_id`) REFERENCES `publisher` (`publisher_id`);

--
-- Constraints for table `model`
--
ALTER TABLE `model`
ADD CONSTRAINT `model_ibfk_1` FOREIGN KEY (`serial_num`) REFERENCES `piano` (`serial_num`),
ADD CONSTRAINT `model_ibfk_2` FOREIGN KEY (`designer_id`) REFERENCES `designer` (`desginer_id`);

--
-- Constraints for table `piano`
--
ALTER TABLE `piano`
ADD CONSTRAINT `piano_ibfk_1` FOREIGN KEY (`emp_num`) REFERENCES `techinican` (`emp_num`);

--
-- Constraints for table `schedule_section`
--
ALTER TABLE `schedule_section`
ADD CONSTRAINT `schedule_section_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `college_course` (`course_id`);

--
-- Constraints for table `student_activity`
--
ALTER TABLE `student_activity`
ADD CONSTRAINT `student_activity_ibfk_2` FOREIGN KEY (`activity_id`) REFERENCES `activity` (`activity_id`),
ADD CONSTRAINT `student_activity_ibfk_3` FOREIGN KEY (`student_phone`) REFERENCES `student` (`student_phone`);

--
-- Constraints for table `techinican`
--
ALTER TABLE `techinican`
ADD CONSTRAINT `techinican_ibfk_1` FOREIGN KEY (`superiver_id`) REFERENCES `techinican` (`emp_num`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
