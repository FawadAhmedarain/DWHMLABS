-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 13, 2019 at 01:35 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `piano manufacture tas2(b)`
--

-- --------------------------------------------------------

--
-- Table structure for table `designer`
--

CREATE TABLE IF NOT EXISTS `designer` (
  `Designer ID` int(10) NOT NULL,
  `Designer name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `designer`
--

INSERT INTO `designer` (`Designer ID`, `Designer name`) VALUES
(1, 'Roland Corporation'),
(2, 'Karimoku'),
(1, 'Roland Corporation'),
(2, 'Karimoku');

-- --------------------------------------------------------

--
-- Table structure for table `model`
--

CREATE TABLE IF NOT EXISTS `model` (
  `Id number` int(10) NOT NULL,
  `name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `model`
--

INSERT INTO `model` (`Id number`, `name`) VALUES
(1, 'Grand Pianos'),
(2, 'Spinet Pianos'),
(1, 'Grand Pianos'),
(2, 'Spinet Pianos');

-- --------------------------------------------------------

--
-- Table structure for table `piano`
--

CREATE TABLE IF NOT EXISTS `piano` (
  `Serial number` int(10) NOT NULL,
  `MFG completion date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `piano`
--

INSERT INTO `piano` (`Serial number`, `MFG completion date`) VALUES
(1, '2019-04-01'),
(2, '2019-03-03'),
(1, '2019-04-01'),
(2, '2019-03-03');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
