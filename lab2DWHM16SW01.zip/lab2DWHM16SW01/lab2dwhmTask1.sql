-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 13, 2019 at 12:57 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `lab2dwhm`
--

-- --------------------------------------------------------

--
-- Table structure for table `hospitaldata`
--

CREATE TABLE IF NOT EXISTS `hospitaldata` (
  `Facility` varchar(30) NOT NULL,
  `Physician` varchar(30) NOT NULL,
  `Ward` varchar(30) NOT NULL,
  `Patient` varchar(30) NOT NULL,
  `Diagnostic unit` varchar(30) NOT NULL,
  `Order` varchar(30) NOT NULL,
  `Supply item` varchar(30) NOT NULL,
  `Vendor` varchar(30) NOT NULL,
  `Service Drug` varchar(30) NOT NULL,
  `Medical item` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hospitaldata`
--

INSERT INTO `hospitaldata` (`Facility`, `Physician`, `Ward`, `Patient`, `Diagnostic unit`, `Order`, `Supply item`, `Vendor`, `Service Drug`, `Medical item`) VALUES
('Lift in Hospital', 'Dr Ayaz', 'Obstetrics', 'Ibrar', 'radiology', '2', 'Box aweeper', 'House keeping', 'lipid profile', 'MRIs '),
('Provide Room for patient', 'Dr Imran', 'Oncology', 'Ali', 'Clinical Laboratory', '2', 'Basket', 'Maintainence Purpose', 'CBC', 'X-rays'),
('Lift in Hospital', 'Dr Ayaz', 'Obstetrics', 'Ibrar', 'radiology', '2', 'Box aweeper', 'House keeping', 'lipid profile', 'MRIs '),
('Provide Room for patient', 'Dr Imran', 'Oncology', 'Ali', 'Clinical Laboratory', '2', 'Basket', 'Maintainence Purpose', 'CBC', 'X-rays');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
