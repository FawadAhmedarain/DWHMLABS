-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 14, 2019 at 08:34 AM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `lab2task2(f)`
--

-- --------------------------------------------------------

--
-- Table structure for table `college course`
--

CREATE TABLE IF NOT EXISTS `college course` (
  `Course ID` int(10) NOT NULL,
  `Course Name` varchar(20) NOT NULL,
  `Units` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `college course`
--

INSERT INTO `college course` (`Course ID`, `Course Name`, `Units`) VALUES
(1, 'java', '5'),
(2, 'php', '3');

-- --------------------------------------------------------

--
-- Table structure for table `schedule section`
--

CREATE TABLE IF NOT EXISTS `schedule section` (
  `Semeste ID` int(20) NOT NULL,
  `Section Number` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schedule section`
--

INSERT INTO `schedule section` (`Semeste ID`, `Section Number`) VALUES
(1, 1),
(2, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `college course`
--
ALTER TABLE `college course`
 ADD PRIMARY KEY (`Course ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
